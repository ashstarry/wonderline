export async function POST() { return Response.json({ error: 'Please reload the studio to use cloud streaming.' }, { status: 410 }); }
