import { chineseSpeechConfig, CHINESE_SPEECH_BUDGET } from '../../../../lib/chinese-router-speech';
import { speechBudgetAvailable } from '../../../../lib/speech-budget';
import type { SpeechEnv } from '../../../../lib/cloud-speech';
export const dynamic = 'force-dynamic';
export async function GET(request: Request) {
  const origin = request.headers.get('origin');
  if (request.headers.get('sec-fetch-site') === 'cross-site' || (origin && origin !== new URL(request.url).origin)) return Response.json({ error: 'Open the cloud studio to try Chinese.' }, { status: 403 });
  try {
    const env = (await import('cloudflare:workers')).env as unknown as SpeechEnv;
    const config = chineseSpeechConfig(env);
    const ready = config.ready && !!env.DB && await speechBudgetAvailable(env.DB, CHINESE_SPEECH_BUDGET);
    return Response.json({ ready, startupError: false, model: config.model, language: 'zh', offline: false, transport: 'cloud', streaming: { mode: 'openrouter-rolling' } }, { headers: { 'Cache-Control': 'no-store' } });
  } catch { return Response.json({ ready: false, error: '中文语音暂时无法连接，请稍后再试。' }, { status: 503 }); }
}
