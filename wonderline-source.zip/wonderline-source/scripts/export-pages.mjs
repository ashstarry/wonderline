import {build} from 'vite';
import {copyFile,writeFile,readdir,readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root=new URL('../',import.meta.url),out=new URL('work/github-pages/',root);
await build({configFile:fileURLToPath(new URL('static-frontend/vite.config.mjs',root))});
for(const folder of ['fonts','demo-narration'])for(const name of await readdir(new URL(`public/${folder}/`,root))){
 if(folder==='demo-narration'&&!name.endsWith('-en.m4a'))continue;
 await copyFile(new URL(`public/${folder}/${name}`,root),new URL(name,out));
}
await copyFile(new URL('public/favicon.svg',root),new URL('favicon.svg',out));
await writeFile(new URL('.nojekyll',out),'');
await writeFile(new URL('README.md',out),`# Wonderline\n\nKeep talking while your imagination takes shape, stroke by stroke.\n\n[Open the studio](https://ashstarry.github.io/wonderline/) · [Original studio](https://softspoken-paper-garden.neonolm3.chatgpt.site/)\n\nThis repository contains the browser-only release for GitHub Pages. Speech recognition and drawing generation run in the existing cloud service. No personal computer serves this website. No API keys, server secrets, recordings, drawing histories or transcripts are included in this repository.\n\nYour drawings and words are stored in your browser on each site's origin; the two addresses do not share that local history.\n\nThe included LXGW Marker Gothic font is licensed under SIL Open Font License 1.1; see OFL-LXGWMarkerGothic.txt and AUTHORS-LXGWMarkerGothic.txt.\n`);
for(const name of await readdir(out)){
 if(!/\.(?:js|html|css|md|txt)$/.test(name))continue;
 const text=await readFile(new URL(name,out),'utf8');
 if(/sk-or-v1-[a-zA-Z0-9]{20,}|sk-[a-zA-Z0-9]{30,}|\/Users\/ashstarry|BEGIN PRIVATE KEY|OPENROUTER_API_KEY|DASHSCOPE_API_KEY/.test(text))throw Error(`Release contains private data: ${name}`);
}
console.log('GitHub Pages browser-only release built and scanned.');
