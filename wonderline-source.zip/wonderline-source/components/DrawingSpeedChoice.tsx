'use client';
import {useEffect,useRef,useState} from 'react';
import {Wind} from 'lucide-react';
import {useLanguage} from './LanguageProvider';
import './drawing-speed-choice.css';

export default function DrawingSpeedChoice({quick,disabled,onChange}:{quick:boolean;disabled:boolean;onChange:(quick:boolean)=>void}) {
 const {language}=useLanguage(),zh=language==='zh';
 const [open,setOpen]=useState(false),root=useRef<HTMLDivElement>(null),trigger=useRef<HTMLButtonElement>(null);
 useEffect(()=>{if(!open)return;const outside=(e:PointerEvent)=>{if(e.target instanceof Node&&!root.current?.contains(e.target))setOpen(false)};const escape=(e:KeyboardEvent)=>{if(e.key==='Escape'){e.stopPropagation();setOpen(false);trigger.current?.focus()}};document.addEventListener('pointerdown',outside);document.addEventListener('keydown',escape);return()=>{document.removeEventListener('pointerdown',outside);document.removeEventListener('keydown',escape)}},[open]);
 return <div ref={root} className="drawing-speed-choice">
  <button ref={trigger} className={`drawing-speed-trigger${quick?' is-quick':''}`} type="button" aria-expanded={open} aria-controls="drawing-speed-options" onClick={()=>setOpen(v=>!v)}><Wind size={20} strokeWidth={1.7} aria-hidden="true"/><span>{quick?(zh?'轻快画笔':'Quick strokes'):(zh?'想快一点？':'A little quicker?')}</span></button>
  {open&&<div className="drawing-speed-panel" id="drawing-speed-options" role="region" aria-label={zh?'画笔速度':'Drawing speed'}>
   <p className="drawing-speed-title">{zh?'给想象加点速':'A little breeze for your ideas'}</p>
   <p>{zh?'轻快模式画得更快，不过细节和准确度可能打点折扣。': 'Quicker drawings, with a little less detail and precision.'}</p>
   <button type="button" className="drawing-speed-switch" role="switch" aria-checked={quick} aria-label={zh?'轻快模式':'Quick mode'} aria-describedby="drawing-speed-note" disabled={disabled} onClick={()=>{onChange(!quick);setOpen(false)}}><span>{zh?'轻快模式':'Quick mode'}</span><span className={`drawing-speed-track${quick?' is-on':''}`} aria-hidden="true"><i/></span></button>
   <small id="drawing-speed-note">{disabled?(zh?'等说完、画完这一笔，就能切换。':'Switch once speaking and drawing have finished.'):(quick?(zh?'随时关掉，回到更细致的画笔。':'Turn it off anytime for more careful drawings.'):(zh?'默认细致作画，想快一点时再打开。':'Off by default, for more careful drawings.'))}</small>
  </div>}
 </div>;
}
