# Wonderline source — custom domain public release

English remains the default. Chinese speech, picturebook, story theatre, companions and rename, paper inspiration, and object manipulation are available on both published frontends.

## Build GitHub Pages

Use Node.js 22.13 or newer. Run `npm ci`, then `node scripts/export-pages.mjs`. The browser-only output is `work/github-pages/`; the same build supports both the legacy `/wonderline/` path and the custom domain root. `CNAME` declares `wonderline.fun`.

The frontend uses the existing hosted cloud API. API keys remain in that server's environment. GitHub Pages does not run server code or receive secrets. The source archive includes server integration code for inspection; deployment identity, environment files, database contents, credentials and local ASR hosting tools are excluded.

Public English retains `/api/speech/realtime`. Chinese uses `/api/speech/chinese` with a language-specific health check. Both feed the shared live drawing queue and lookahead pipeline. Only the exact configured GitHub origin is allowed by the cloud gateway; no wildcard origins or client API keys.

## Verify locally

Run `node --test tests/*.test.mjs` for the offline regression suite and `npx tsc --noEmit --incremental false` for type checking. The tests use mocks and synthetic fixtures, not paid model calls.

Companion renaming preserves saved identity and artwork and updates scene/history labels. Drawings, words, companions and picturebook are stored in each visitor's browser, separately per website origin. No personal recordings, drawings or transcripts are included in this archive.

The font in `public/fonts/` includes its OFL licence and attribution files.
