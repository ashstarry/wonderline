# Wonderline source — companion rename release

This is the source for the English GitHub Pages release, including its cloud API integration code. No credentials, local recordings, drawings, transcripts, test pages, runtime state, or local ASR host are included.

## Build the public English frontend

Use Node.js 22.13 or newer. Run `npm ci`, then `node scripts/export-pages.mjs`. The browser-only output is written to `work/github-pages/`. The base path is `/wonderline/`.

The frontend uses the existing hosted cloud API. Its API keys remain in that server's environment. GitHub Pages does not run the server code or receive its secrets.

`__WONDERLINE_PAGES__` keeps the public build English-only and uses the existing ASR route. Companions, including rename, are enabled. Chinese speech, picturebook, story theatre and experimental inspiration remain outside the public UI.

Run offline regression checks with `node --test tests/companion-rename.test.mjs tests/story-companions.test.mjs tests/companion-turn.test.mjs tests/companion-shelf.test.mjs tests/companion-voice.test.mjs tests/experimental-release.test.mjs tests/drawing-lookahead.test.mjs tests/live-painting.test.mjs tests/painter-regions.test.mjs tests/stroke-playback.test.mjs tests/rolling-speech.test.mjs tests/chinese-stream-continuity.test.mjs`. These do not call paid models.

Companions and drawings are stored in the visitor's browser. Renaming retains the saved identity and artwork, updates scene/history name metadata, and makes the new name available to the existing voice recall path. It does not generate new artwork or alter ASR, drawing prompts, or animation scheduling.

The font in `public/fonts/` includes its own OFL licence and attribution files.
