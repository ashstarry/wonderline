import { routerSpeechWebSocket } from './router-speech';
import type { SpeechEnv } from './cloud-speech';

/** Cloud-studio experiment only. The existing Pages endpoint remains untouched. */
export async function speechOnlyEnglishWebSocket(request: Request, env: SpeechEnv, ctx: ExecutionContext) {
  const url = new URL(request.url);
  if (url.pathname !== '/api/speech/english' || url.protocol !== 'https:' || url.search ||
    request.headers.get('origin') !== url.origin || request.headers.get('sec-fetch-site') === 'cross-site' ||
    url.origin === 'https://ashstarry.github.io') return Response.json({ error: 'Open the cloud studio to record.' }, { status: 403 });
  if (env.ASR_PROVIDER !== 'openrouter') return Response.json({ error: 'Voice is not available yet.' }, { status: 503 });
  return routerSpeechWebSocket(request, env, ctx, true);
}
