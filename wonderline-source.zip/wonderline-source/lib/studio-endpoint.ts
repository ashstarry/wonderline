/** Public addresses only. Secrets remain in the hosted Worker. */
declare const __WONDERLINE_PAGES__: boolean | undefined;
export const CLOUD_STUDIO_ORIGIN = 'https://softspoken-paper-garden.dongyuanshun.chatgpt.site';
export function isPagesBuild() { return typeof __WONDERLINE_PAGES__ !== 'undefined' && __WONDERLINE_PAGES__ === true; }
export function studioApi(path: string) { return isPagesBuild() ? `${CLOUD_STUDIO_ORIGIN}${path}` : path; }
function browserBase() {
  return typeof window === 'undefined' || window.location?.hostname === 'ashstarry.github.io' ? '/wonderline/' : '/';
}
export function studioPage(path: string) { return isPagesBuild() ? `${browserBase()}${path === '/' ? '' : `?view=${path.slice(1)}`}` : path; }
export function studioAsset(path: string) { return isPagesBuild() ? `${browserBase()}${path.split('/').pop()}` : path; }
