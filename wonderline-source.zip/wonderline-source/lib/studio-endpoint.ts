/** Public addresses only. Secrets remain in the hosted Worker. */
declare const __WONDERLINE_PAGES__: boolean | undefined;
export const CLOUD_STUDIO_ORIGIN = 'https://softspoken-paper-garden.neonolm3.chatgpt.site';
export function isPagesBuild() { return typeof __WONDERLINE_PAGES__ !== 'undefined' && __WONDERLINE_PAGES__ === true; }
export function studioApi(path: string) { return isPagesBuild() ? `${CLOUD_STUDIO_ORIGIN}${path}` : path; }
export function studioPage(path: string) { return isPagesBuild() ? `/wonderline/${path === '/' ? '' : `?view=${path.slice(1)}`}` : path; }
export function studioAsset(path: string) { return isPagesBuild() ? `/wonderline/${path.split('/').pop()}` : path; }
